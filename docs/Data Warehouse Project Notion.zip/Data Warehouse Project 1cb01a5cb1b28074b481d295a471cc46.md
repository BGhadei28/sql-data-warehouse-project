# Data Warehouse Project

[DWH Epics](DWH%20Epics%201cb01a5cb1b280df90e9cbdcc0687618.csv)

[DWH Tasks](DWH%20Tasks%201cb01a5cb1b2803b89a5feb94deb1cbb.csv)